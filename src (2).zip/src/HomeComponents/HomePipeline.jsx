// src/homeComponents/HomePipeline.jsx

const pipelineSteps = [
  "Create a profile",
  "Collect observations",
  "Store and export data",
  "Review reports",
];

export default function HomePipeline() {
  return (
    <section className="scroll-mt-24 bg-white px-6 py-20 text-[#071b1d] sm:py-24">
      <div className="mx-auto max-w-6xl">
        <div className="mx-auto max-w-3xl text-center">
          <p className="text-sm font-semibold uppercase tracking-[0.25em] text-[#5f7659]">
            Observation to analysis
          </p>

          <h2 className="mt-4 text-4xl font-black tracking-tight sm:text-5xl">
            Pipeline section placeholder
          </h2>

          <p className="mt-5 text-base leading-7 text-[#3f5138] sm:text-lg">
            This section will show the main ResearchObs workflow from animal
            observation to organized data output and analysis-ready reporting.
          </p>
        </div>

        <div className="mt-12 grid gap-5 md:grid-cols-4">
          {pipelineSteps.map((step, index) => (
            <div
              key={step}
              className="rounded-3xl border border-black/10 bg-[#f7f5ef] p-6 text-center shadow-sm"
            >
              <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-[#5f7659] text-sm font-black text-white">
                {index + 1}
              </div>

              <h3 className="mt-5 text-lg font-black">{step}</h3>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
