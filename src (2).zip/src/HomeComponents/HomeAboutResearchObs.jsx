// src/homeComponents/homeAboutResearchObs.jsx

import mainPageImage from "../assets/core-features/main-page.png";

export default function HomeAboutResearchObs() {
  return (
    <section className="scroll-mt-24 bg-[#f7f5ef] px-6 py-20 text-[#102820] sm:py-24">
      <div className="mx-auto grid max-w-6xl items-center gap-12 lg:grid-cols-[0.95fr_1.05fr] lg:gap-16">
        <div>
          <p className="text-sm font-semibold uppercase tracking-[0.25em] text-[#5f7659]">
            About ResearchObs
          </p>

          <h2 className="mt-4 max-w-xl text-4xl font-black tracking-tight text-[#071b1d] sm:text-5xl">
            What is ResearchObs?
          </h2>

          <p className="mt-6 max-w-xl text-lg leading-8 text-[#24362f] sm:text-xl">
            ResearchObs is a{" "}
            <span className="underline decoration-[#5f7659] decoration-2 underline-offset-4">
              free
            </span>{" "}
            behavioral data collection app developed with species and ethogram
            versatility so that anyone, including researchers, care staff, and
            hobbyists, can collect behavioral data from their animals to drive
            welfare and research projects.
          </p>
        </div>

        <div className="relative mx-auto flex w-full justify-center [perspective:1400px]">
          <div className="absolute left-4 top-10 h-48 w-48 rounded-full bg-[#b8dd54]/25 blur-3xl" />
          <div className="absolute right-6 bottom-10 h-56 w-56 rounded-full bg-[#3f5138]/20 blur-3xl" />

          <div
            className="relative aspect-[10/16] w-[min(72vw,23rem)] rounded-[2.25rem] bg-linear-to-br from-[#202421] via-[#0d1110] to-[#050706] p-3 shadow-[0_34px_90px_rgba(7,27,29,0.34),0_14px_32px_rgba(7,27,29,0.24),inset_0_2px_2px_rgba(255,255,255,0.18)]"
            style={{
              transform: "rotateX(5deg) rotateY(-13deg) rotateZ(1deg)",
            }}
          >
            <div className="absolute left-1/2 top-1.5 h-1.5 w-14 -translate-x-1/2 rounded-full bg-white/14" />
            <div className="absolute left-1/2 bottom-2 h-3 w-3 -translate-x-1/2 rounded-full border border-white/15 bg-white/8" />

            <div className="h-full w-full overflow-hidden rounded-[1.65rem] border border-white/10 bg-[#071b1d] shadow-[inset_0_0_0_1px_rgba(255,255,255,0.08)]">
              <img
                src={mainPageImage}
                alt="ResearchObs home page displayed on a tablet mockup"
                className="h-full w-full object-cover object-top"
                loading="lazy"
                decoding="async"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
